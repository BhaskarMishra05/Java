public class string{
    public static void main(String[] args){
        @SuppressWarnings("unused")
        String text =" This is an example of string!";
        System.out.println("This is a string and legth o fthe upper string is " + text.length());
    }
}