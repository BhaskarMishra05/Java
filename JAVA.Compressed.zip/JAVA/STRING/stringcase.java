public class stringcase{
    public static void main(String[] args) {
        @SuppressWarnings("unused")
        String text =" This is an example of string";
        System.out.println("This is an example o fupper case stringcase = '" + (text.toUpperCase()) + " '");
        System.out.println("This is an example of lower case stringcase = '" + (text.toLowerCase()) + " '");

    }
}