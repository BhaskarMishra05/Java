public class concatenation{ // it is used for merging strings
    public static void main(String[] args) {
        String firstname ="John";
        String lastname = "Snow";
        System.out.println(firstname + " " + lastname); // With space
        // ALSO 
        System.out.println(firstname.concat(lastname)); // Without space
    }
}