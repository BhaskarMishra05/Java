public class char_in_string{
    public static void main(String[] args) {
        @SuppressWarnings("unused")
        // Finding the index value of a character in string.
        String text = "Dogs, or kukurs, are loyal and intelligent animals. They are kept as pets, used for security, and even assist in rescue operations. Known for their strong bond with humans, dogs provide companionship and protection. They come in various breeds, sizes, and temperaments, making them ideal pets for different lifestyles.";
        System.out.println(text.indexOf("kukurs"));
        String apl =" A B C D E F G H I J K L M N O P Q R S T U V W X Y Z ";
        System.out.println(apl.indexOf("F"));
    }
}