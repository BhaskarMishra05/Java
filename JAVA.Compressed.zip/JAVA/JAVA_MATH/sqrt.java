public class sqrt{
    public static void main(String[] args) {
        System.out.println(Math.sqrt(7));
        System.out.println(Math.random());
    }
}