public class max_min{
    public static void main(String[] args) {
        int x = 10;
        int y = 12;
        int z = 19;
        int a = 14;
        int b = 17;
        int c = 16;
        System.out.println(Math.max(x,Math.max(y,Math.max(z,Math.max(a,Math.max(b,c))))));
        System.out.println(Math.min(x,Math.min(y,Math.min(z,Math.min(a,Math.min(b,c))))));
    }
}