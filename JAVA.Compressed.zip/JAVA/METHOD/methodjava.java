public class methodjava{
    static void mymethod(){
        System.out.println("This is a method");
    }
    public static void main(String[] args) {
       mymethod(); 
    }
}