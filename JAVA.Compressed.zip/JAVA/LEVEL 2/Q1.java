// Write a Java program to find the factorial of a number.
import java.util.Scanner;
public class Q1{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number: ");
        int number = scanner.nextInt();
        int multi=1;
        for(int i=1;i<=number;i++){
            multi*=i;

        }
        System.out.println(multi);

    }
}