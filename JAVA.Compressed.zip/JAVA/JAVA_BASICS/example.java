public class example{
    public static void main(String[] args){
        String Studentname="Bhaskar Mishra";
        int StudentRollnumber= 7416207;
        float StudentPercentage= 74.78f;
        char StudentGrade='B';
        System.out.println("STUDENT NAME = " + Studentname);
        System.out.println("STUDENT ROLL NUMBER = " + StudentRollnumber);
        System.out.println("STUDENT PERCENTAGE = " + StudentPercentage);
        System.out.println("STUDENT GRADES = " + StudentGrade);      
    }
}