public class printlnvsprint{
    public static void main(String[] args){
        System.out.println("This is an example of println method");
        System.out.println("This is new line");
        System.out.print("This is an example of print method");
        System.out.print("This is new line");
    }
}
// Print function does not create new line automatically
