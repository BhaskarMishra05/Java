public class displayvariable{
    public static void main(String[] args){
        String name ="John";
        System.out.println("Hello " + name + " Snow");
        String firstname="monkey";
        String lastname = " luffy";
        String fullname = firstname+ lastname;
        System.out.println(fullname);
        int x,y,z,a,b,c = 7;
        x=y=z=a=b=c; // All variable as 7
        int total=x+y+z+a+b+c;
        System.out.println(total);
    }
}