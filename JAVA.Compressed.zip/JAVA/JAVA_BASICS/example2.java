public class example2{
    public static void main (String[] args){
        String nameofproduct="Apple";
        int numberofitems=50;
        @SuppressWarnings("unused")
        String weightofproduct= "15kg" ;
        float priceperpiece = 15f;
        float cost = numberofitems * priceperpiece;
        System.out.println("Name of product = " + nameofproduct);
        System.out.println("Total number of items purchased = " + numberofitems);
        System.out.println("Total cost of items = " + cost);


    }
    
}