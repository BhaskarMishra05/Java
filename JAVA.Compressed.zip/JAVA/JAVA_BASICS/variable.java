public class variable{
    public static void main(String[] args){
        String name = "Puccio";
        System.out.println(name);
        int number = 78;
        System.out.println(number);
        float floating = 34.890f;
        System.out.println(floating);
        char  letter = 'L'; // Single quote for char and double and single for string
        System.out.println(letter);
        boolean bool = true;
        System.out.println(bool);
    }
}