public class printnumber{
    public static void main(String [] args){
        System.out.println(345);
        System.out.println(3+3);
        System.out.println(3*3);
        System.out.println(3/3);
        System.out.println(3-3);
    }
}