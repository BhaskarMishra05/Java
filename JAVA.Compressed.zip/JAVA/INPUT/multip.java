import java.util.Scanner;
public class multip{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter first number= ");
        int x = scanner.nextInt();
        System.out.print("Enter second number= ");
        int y = scanner.nextInt();
        int multi= x*y;
        System.out.print("The multiplication of both numbers is = " + multi);

    }
}