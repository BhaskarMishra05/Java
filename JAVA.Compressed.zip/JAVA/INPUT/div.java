import java.util.Scanner;
public class div{
    public static void main(String[] args) {
        Scanner scanner =new Scanner ( System.in);
        System.out.print("Enter the first number = ");
        int x = scanner.nextInt();
        System.out.print("Enter second number = ");
        int y = scanner.nextInt ();
        float divide= x/y;
        if(x == 0 || y == 0){
            System.out.print("INVALID");
        }
        else{
            System.out.print("The division of both numbers is = " + divide );
        }
    }
}