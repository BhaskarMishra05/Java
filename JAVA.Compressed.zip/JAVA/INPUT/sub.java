import java.util.Scanner;
public class sub{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter first number = ");
        int x = scanner.nextInt();
        System.out.print("Enter second number = ");
        int y = scanner.nextInt();
        int sub=x - y;
        System.out.print ("The subtraction of both number is = " + sub);
    }
}