import java.util.Scanner; // Import the Scanner class

public class inputjava {
    public static void main(String[] args) {
        // Create a Scanner object
        @SuppressWarnings("unused")
        Scanner scanner = new Scanner(System.in);

        // Ask for input
        System.out.print("Enter your name: ");
        String name = scanner.nextLine(); // Read a string input

        System.out.print("Enter your age: ");
        int age = scanner.nextInt(); // Read an integer input

        // Output the input
        System.out.println("Hello, " + name + "! You are " + age + " years old.");

        // Close the scanner (optional but recommended)
        scanner.close();
    }
}