import javax.swing.*;
import java.awt.*;

public class Multi_button {
    public static void main(String[] args) {
        // CREATING WINDOW
        JFrame frame = new JFrame("Multi-Button Window");
        frame.setSize(500, 400);
        frame.setLayout(new BorderLayout(10, 10));

        // CREATE OUTPUT LABEL
        JLabel outputLabel = new JLabel("Output will be shown here");
        outputLabel.setFont(new Font("Arial", Font.BOLD, 14));
        outputLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        outputLabel.setHorizontalAlignment(SwingConstants.CENTER);

        // CREATE A PANEL FOR BUTTONS
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(5, 2, 5, 5)); // 5 rows, 2 columns

        // SHORTER TEXT FOR BUTTONS
        String[] buttonLabels = {
                "चैन क्यों नहीं?", "बहुत अजीब हूँ", "मोहब्बत नहीं हुई",
                "बेकार हूँ", "कुछ नहीं सोचता", "यक़ीन था",
                "रोना ही काम", "घर की देखभाल", "भूल गए थे?", "किस हक़ से?"
        };

        // FULL TEXT FOR OUTPUT
        String[] fullTexts = {
                "You complete me.","I’m yours forever.",
                "You’re my everything.",
                "You light up my life.",
                "I love you more each day.",
                "You’re my heart’s home.",
                "Forever and always.",
                "You’re my soulmate.",
                "My heart is yours.","You are my happy place."

        };

        // CREATE BUTTONS DYNAMICALLY
        for (int i = 0; i < buttonLabels.length; i++) {
            String text = fullTexts[i]; // Get full text for output
            JButton jbt = new JButton(buttonLabels[i]); // Button with short text
            jbt.addActionListener(e -> outputLabel.setText("<html>Output:<br>" + text + "</html>")); // Show full text
            buttonPanel.add(jbt);
        }

        // ADD COMPONENTS TO FRAME
        frame.add(buttonPanel, BorderLayout.CENTER);
        frame.add(outputLabel, BorderLayout.SOUTH);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
