import javax.swing.*;
import java.awt.event.*;
public class division_window {
    public static void main(String[] args){
        JFrame frame = new JFrame("Division!");
        frame.setSize(400,300);
        JButton button = new JButton("Enter!");
        JTextField tf1 = new JTextField(10);
        JTextField tf2 = new JTextField(10);
        JPanel panel = new JPanel();
        JLabel label = new JLabel("The division will be shown here: ");
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    int input1 = Integer.parseInt(tf1.getText());
                    int input2 = Integer.parseInt(tf2.getText());
                    int divion = input1 / input2;
                    label.setText("Division: " + divion);
                }
                catch (NumberFormatException ex){
                    label.setText("INVALID INPUT");
                }
            }
        });
        panel.add(tf1);
        panel.add(tf2);
        panel.add(button);
        panel.add(label);
        frame.setVisible(true);
        frame.add(panel);



    }
}