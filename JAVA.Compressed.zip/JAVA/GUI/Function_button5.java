import javax.swing.*;
import java.awt.event.*;
public class Function_button5 {
    public static void main (String[] args){
        JFrame frame = new JFrame("CLICK ME !");
        frame.setSize(700,600);
        JTextField textfield1= new JTextField(10);
        JTextField textfield2 = new JTextField(20);
        JButton  button = new JButton("Enter here :3");
        button.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                int input1 = Integer.parseInt(textfield1.getText());
                int input2 = Integer.parseInt(textfield2.getText());
                int sum = input1 + input2;

                System.out.println(sum);

            }
        });
        JPanel panel = new JPanel();
        panel.add(button);
        panel.add(textfield1);
        panel.add(textfield2);
        frame.setVisible(true);
        frame.add(panel);
    }
}