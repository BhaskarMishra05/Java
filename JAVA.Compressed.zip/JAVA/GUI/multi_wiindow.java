import javax.swing.*;
import java.awt.event.*;
public class multi_wiindow {
    public static void main(String[]args){
        JFrame frame = new JFrame("Title");
        frame.setSize(940,300);
        JButton button = new JButton("Enter");
        JTextField Tf1 = new JTextField(10);
        JTextField Tf2 = new JTextField(20);
        JPanel panel = new JPanel();
        JLabel label = new JLabel("The Multiplication will be shown  here: ");
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    int input1 = Integer.parseInt(Tf1.getText());
                    int input2 = Integer.parseInt(Tf2.getText());
                    int multi = input2 * input1;
                    label.setText("Multi: " + multi);
                }
                catch(NumberFormatException ex){
                    label.setText("INVALID INPUT");
                }
            }

        });
        panel.add(Tf1);
        panel.add(Tf2);
        panel.add(label);
        panel.add(button);
        frame.add(panel);
        frame.setVisible(true);

    }
}

