import java.awt.event.*;
import javax.swing.*;
public class Functional_button2 {
    public static void main(String[] args) {
        JFrame frame =  new JFrame("Funtional button");
        frame.setSize(200,200);
        JButton button = new JButton("CLICK ME!");
        //frame.setSize(20,30);
        button.addActionListener(new ActionListener (){
            public void actionPerformed(ActionEvent e){
                System.out.println("GO STUDY BITCH!");
            }

        });
        frame.add(button);
        frame.setVisible(true);

    }
}