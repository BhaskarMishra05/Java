import javax.swing.*;
import java.awt.event.*;
public class Functinal_button4 {
    public static void main(String[] args){
        JFrame frame = new JFrame("YOOO");
        frame.setSize(400,200);
        JButton button = new JButton("CLICK ME ");
        frame.setSize(700,600);
        JTextField textfield=  new JTextField(20);
        button.addActionListener( new ActionListener(){
            public void actionPerformed(ActionEvent e) {
                String input = textfield.getText();
                System.out.println("THE INPUT IS: " + input);
            }
        });
        JPanel panel = new JPanel ();
        panel.add(textfield);
        panel.add(button);
        frame.setVisible(true);
        frame.add(panel);
    }
}
