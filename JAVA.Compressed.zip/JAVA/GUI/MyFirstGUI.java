import javax.swing.*;
public class MyFirstGUI{
    public static void main(String[] args) {
        JFrame frame = new JFrame("This is a Window");
        frame.setSize(200,200);
        JButton button = new JButton("This is a button");
        frame.add(button);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);


    }
}
