import java.awt.event.*;
import javax.swing.*;

public class Functional_button3 {
    public static void main(String[] args) {
        JFrame frame = new JFrame("CLICK ME");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Close on exit

        JTextField textfield = new JTextField(10); // Set text field size
        JButton button = new JButton("CLICK ME");

        // ADD ACTION LISTENER
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String input = textfield.getText();
                System.out.println("THE INPUT IS: " + input);
            }
        });

        JPanel panel = new JPanel();
        panel.add(textfield);
        panel.add(button);

        frame.add(panel); // Add panel instead of button
        frame.setVisible(true);
    }
}
