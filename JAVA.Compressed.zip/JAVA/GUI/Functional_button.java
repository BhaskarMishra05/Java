import java.awt.event.*;
import javax.swing.*;

public class Functional_button{
    public static void main(String[] args) {
        JFrame frame = new JFrame("Functional button");
        frame.setSize(200,400);
        JButton button = new JButton("CLICK ME ");
        button.addActionListener(new ActionListener () {
            public void actionPerformed(ActionEvent e){
                System.out.println("Hello World!");
            }
        });
        frame.add(button);
        frame.setVisible(true);

    }
}
