import javax.swing.*;
import java.awt.event.*;
public class sub_window {
    public static void main(String[] args) {
        JFrame frame = new JFrame("SUBTRACTION!");
        frame.setSize(570, 380);
        JButton button = new JButton("ENTER");
        JPanel panel = new JPanel();
        JTextField textField1 = new JTextField(10);
        JTextField textField2 = new JTextField(20);
        JLabel label = new JLabel("The Subtraction is displayed here: ");
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    int input1 = Integer.parseInt(textField1.getText());
                    int input2 = Integer.parseInt(textField2.getText());
                    int sub = input1 - input2;
                    label.setText("Sub: " + sub);
                } catch (NumberFormatException ex) {
                    label.setText("INVALID INPUT");
                }

            }
        });
        panel.add(button);
        panel.add(textField1);
        panel.add(textField2);
        panel.add(label);
        frame.add(panel);
        frame.setVisible(true);
    }

}
