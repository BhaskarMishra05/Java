public class modify_final_variable{
    final int x =90;
    public static void main(String[] args) {
        modify_final_variable obj = new modify_final_variable();
        // obj.x = 78; // error occured because the field is declared with 'final' keyword thus the value of x can't be changed.
        System.out.println(obj.x);
    }
}