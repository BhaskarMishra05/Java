public class method{
    static void mymethod(){
        System.out.println("This is a method!");
    }
    public static void main(String[] args) {
        mymethod(); // method calling in main 
    }
}