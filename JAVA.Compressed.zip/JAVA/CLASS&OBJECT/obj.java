public class obj {
  int x = 5;

  public static void main(String[] args) {
    obj myObj = new obj();
    System.out.println(myObj.x);
  }
}
