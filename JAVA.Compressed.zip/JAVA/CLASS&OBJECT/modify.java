public class modify{
    int x;
    public static void main(String[] args) {
        modify obj = new modify();
        obj.x= 69;
        System.out.println(obj.x);
    }
}