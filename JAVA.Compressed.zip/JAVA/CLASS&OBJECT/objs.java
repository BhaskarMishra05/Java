public class objs{
    int x = 5;
    int y = 7;
    public static void main(String[] args) {
        objs obj1 = new objs();
        objs obj2 = new objs();
        System.out.println("Obj of first class " + obj1.x);
        System.out.println("Obj of second class " + obj2.y);

    }
}