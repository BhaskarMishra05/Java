public class multiple_attributes{
    String fname="John";
    String lname="Snow";
    int age = 29;
    public static void main(String[] args) {
        multiple_attributes obj = new multiple_attributes();
        System.out.println("Hi,my name is " + obj.fname +" "+ obj.lname + " and my age is " + obj.age);
    }

}