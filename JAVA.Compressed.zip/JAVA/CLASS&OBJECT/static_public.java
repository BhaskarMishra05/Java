public class static_public{
    static void staticmethod(){
        System.out.println("This is an example of static method!");
        // method with static keyword don't need any object to initiate.
    }
    public void publicmethod(){
        System.out.println("This is an example of public method!");
        // method with public keyword needs an object to initialize.
    }
    public static void main(String[] args) {
        staticmethod();
        static_public obj = new static_public();
        obj.publicmethod();
    }
}
