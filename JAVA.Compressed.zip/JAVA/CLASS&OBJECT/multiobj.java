public class multiobj{
    int x = 67;
    public static void main(String[] args){
        multiobj obj1 = new multiobj();
        multiobj obj2 = new multiobj();
        obj2.x = 23;
        System.out.println(obj1.x);
        System.out.println(obj2.x);
        

    }
}