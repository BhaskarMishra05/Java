public class arrayloop{
    public static void main (String[] args){
        char[] alphabet = {'A','B','C','D','E','F','G','H','I'};
        int lengthofalphabet = alphabet.length;
        for (int i = 0 ; i< lengthofalphabet ; i++){
            System.out.println(alphabet[i]);
        }
    }
}