public class arrayjava{
    public static void main(String[] args) {
        String[] car = {"car1","car2","car3","car4","car5"};
        System.out.println(car[0]);

        int[] number={1,2,3,4,5,6,7,8,9,10};
        System.out.println(number[2]);

        System.out.println("Length of car array =  " + car.length);
        System.out.println("Length of number array =  " + number.length);
    }
}