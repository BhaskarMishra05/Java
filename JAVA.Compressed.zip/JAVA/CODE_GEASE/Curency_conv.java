import java.util.Scanner;
public class Curency_conv {
    public static void main(String[]args){
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Currency in INR: ");
        float currency = scanner.nextFloat();
        Double dollor_conversion = currency / 86.88;
        System.out.print("Currency in USD: $"+dollor_conversion);
    }
}
