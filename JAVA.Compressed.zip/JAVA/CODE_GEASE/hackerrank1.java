import java.util.Scanner;
import java.util.Scanner.*;
public class hackerrank1 {
    public static void main(String[]args){
        Scanner scanner = new Scanner(System.in);
        int x = scanner.nextInt();
        int y = scanner.nextInt();
        int z = scanner.nextInt();
        System.out.println(x);
        System.out.println(y);
        System.out.println(z);

    }
}
