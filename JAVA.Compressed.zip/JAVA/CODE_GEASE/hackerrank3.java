import java.util.Scanner;
public class hackerrank3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int Integer = scanner.nextInt();
        double db = scanner.nextDouble();
        String stri = scanner.next();
        System.out.println(Integer);
        System.out.println(db);
        System.out.println(stri);

    }
}