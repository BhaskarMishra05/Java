import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class BrickBreaker extends JPanel implements ActionListener {
    private Timer timer;
    private int ballX = 300, ballY = 300, ballDirX = -1, ballDirY = -2;
    private int paddleX = 250, paddleY = 450;
    private boolean left = false, right = false;
    private int score = 0;
    private boolean[][] bricks = new boolean[3][5]; // 3 rows, 5 columns of bricks

    public BrickBreaker() {
        setPreferredSize(new Dimension(600, 600));
        setBackground(Color.BLACK);
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_LEFT) left = true;
                if (e.getKeyCode() == KeyEvent.VK_RIGHT) right = true;
            }
            @Override
            public void keyReleased(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_LEFT) left = false;
                if (e.getKeyCode() == KeyEvent.VK_RIGHT) right = false;
            }
        });
        setFocusable(true);
        timer = new Timer(5, this);
        timer.start();

        // Initialize bricks
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 5; j++) {
                bricks[i][j] = true; // All bricks are initially present
            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // Ball movement
        ballX += ballDirX;
        ballY += ballDirY;

        // Ball collision with walls
        if (ballX <= 0 || ballX >= getWidth() - 10) ballDirX = -ballDirX;
        if (ballY <= 0) ballDirY = -ballDirY;

        // Ball collision with paddle
        if (ballY >= paddleY - 10 && ballY <= paddleY && ballX >= paddleX && ballX <= paddleX + 100) {
            ballDirY = -ballDirY;
            score++;
        }

        // Ball falls below the paddle
        if (ballY >= getHeight()) {
            timer.stop();
            JOptionPane.showMessageDialog(this, "Game Over! Final Score: " + score);
        }

        // Paddle movement
        if (left && paddleX > 0) paddleX -= 5;
        if (right && paddleX < getWidth() - 100) paddleX += 5;

        // Check for brick collisions
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 5; j++) {
                if (bricks[i][j] && ballX >= 100 * j && ballX <= 100 * (j + 1) && ballY >= 30 + 30 * i && ballY <= 30 + 30 * (i + 1)) {
                    bricks[i][j] = false; // Destroy the brick
                    ballDirY = -ballDirY; // Bounce the ball off the brick
                    score += 5; // Increase the score for breaking a brick
                }
            }
        }

        repaint();
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        // Draw the ball
        g.setColor(Color.RED);
        g.fillRect(ballX, ballY, 10, 10);

        // Draw the paddle
        g.setColor(Color.GREEN);
        g.fillRect(paddleX, paddleY, 100, 10);

        // Draw the bricks
        g.setColor(Color.CYAN);
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 5; j++) {
                if (bricks[i][j]) {
                    g.fillRect(100 * j, 30 + 30 * i, 100, 30);
                }
            }
        }

        // Display the score
        g.setColor(Color.WHITE);
        g.drawString("Score: " + score, 10, 20);
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Brick Breaker");
        BrickBreaker game = new BrickBreaker();
        frame.add(game);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
