import java.util.Scanner;
public class simple_calculator{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the first number: ");
        double number1 = sc.nextDouble();
        System.out.print("Enter second number : ");
        double number2 = sc.nextDouble();
        System.out.print("Enter the operator (+ , - , * , / ): ");
        char operator = sc.next().charAt(0);
        double result = 0;
        // @SuppressWarnings("unused")
        switch (operator){
            case '+' ->  {
                result = number1+number2;
                break;
            }
            case '-' ->  {
                result = number1-number2;
                break;
            }
            case '*' ->  {
                result = number1*number2;
                break;
            }
            case '/' ->  {
                result = number1/number2;
                break;
            }
            default -> {
                System.out.print("INVALID OPERATOR. ");
            }
        }
        System.out.print(result);

    }
}