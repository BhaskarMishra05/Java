import java.util.Scanner;
public class largestnumber{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter first number - ");
        int x = scanner.nextInt();
        System.out.print("Enter second number - ");
        int y = scanner.nextInt();
        System.out.print("Enter third number - ");
        int z = scanner.nextInt();
        int maxnumber = Math.max(x,(Math.max(y,z)));
        System.out.println("THE LARGEST NUMBER IS : " + maxnumber);
        int minnumber = Math.min(x,Math.min(y,z));
        System.out.println("THE SMALLEST NUMBER IS : " + minnumber);
    }
}