public class hackerrank5 {
}
