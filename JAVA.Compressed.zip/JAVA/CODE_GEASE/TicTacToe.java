import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class TicTacToe extends JFrame implements ActionListener {
    private JButton[] buttons = new JButton[9];
    private boolean xTurn = true; // If true, it's "X"'s turn; otherwise "O"'s turn.
    private int[] board = new int[9]; // To track board state, 0 = empty, 1 = X, 2 = O.

    public TicTacToe() {
        setTitle("Tic-Tac-Toe");
        setLayout(new GridLayout(3, 3));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 300);

        // Initialize the buttons and add them to the board
        for (int i = 0; i < 9; i++) {
            buttons[i] = new JButton("");
            buttons[i].setFont(new Font("Arial", Font.PLAIN, 60));
            buttons[i].addActionListener(this);
            add(buttons[i]);
        }
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JButton source = (JButton) e.getSource();
        int index = -1;

        // Find the index of the clicked button
        for (int i = 0; i < 9; i++) {
            if (source == buttons[i]) {
                index = i;
                break;
            }
        }

        // Check if the cell is already occupied
        if (board[index] != 0) {
            return;
        }

        // Mark the button with "X" or "O"
        if (xTurn) {
            source.setText("X");
            board[index] = 1;  // Mark X
        } else {
            source.setText("O");
            board[index] = 2;  // Mark O
        }

        // Check for a winner
        if (checkWinner()) {
            String winner = xTurn ? "X" : "O";
            JOptionPane.showMessageDialog(this, winner + " Wins!");
            resetGame();
        } else {
            // Change turn
            xTurn = !xTurn;
        }
    }

    private boolean checkWinner() {
        // Check all winning combinations
        int[][] winningCombinations = {
                {0, 1, 2}, {3, 4, 5}, {6, 7, 8},  // Rows
                {0, 3, 6}, {1, 4, 7}, {2, 5, 8},  // Columns
                {0, 4, 8}, {2, 4, 6}               // Diagonals
        };

        for (int[] combination : winningCombinations) {
            int a = combination[0], b = combination[1], c = combination[2];
            if (board[a] != 0 && board[a] == board[b] && board[b] == board[c]) {
                return true;
            }
        }
        return false;
    }

    private void resetGame() {
        // Reset the board and button texts
        for (int i = 0; i < 9; i++) {
            buttons[i].setText("");
            board[i] = 0;
        }
        xTurn = true;  // X starts the new game
    }

    public static void main(String[] args) {
        new TicTacToe();
    }
}
