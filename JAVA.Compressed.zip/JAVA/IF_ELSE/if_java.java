public class if_java{
    public static void main(String[] args) {
        if(20>18){
            System.out.println("20 is greater than 18");
        }
    }
}