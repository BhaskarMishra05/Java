public class whileloop {
    public static void main(String[] args) {
        int i =0;
        while(i<10){ //while(condition)
            System.out.println(i);
            ++i;    // condition at the bottom .  unlike for loop.
        }
    }
}