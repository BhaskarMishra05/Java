public class plus{
    public static void main(String[] args){
        int x = 89;
        int y = 45;
        int z = 23;
        System.out.println("x + y = " + (x+y));
        System.out.println("x / z = " + (x/z));
        System.out.println("x * y * z = " + (x*y*z));
        System.out.println("x % z = " + (x%z));
        System.out.println("Incrementing x by 1 = " + (++x)); // x = 90
        System.out.println("Decrementing x by 1 = " + (--x)); // bring x back to 89
        System.out.println("Comparision x > y = " + (x>y));
    }
}