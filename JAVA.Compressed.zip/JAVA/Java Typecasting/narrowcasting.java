public class narrowcasting{
    public static void main(String[] args) {
        double dco = 456.987d;
        int flow = (int) dco;
        System.out.println(dco);
        System.out.println(flow);



    }
}
