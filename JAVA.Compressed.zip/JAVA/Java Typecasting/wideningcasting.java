public class wideningcasting{
    public static void main(String[] args){
        @SuppressWarnings("unused")
        int x =69;
        @SuppressWarnings("unused")
        double y = x ;
        System.out.println(y);

    }
}